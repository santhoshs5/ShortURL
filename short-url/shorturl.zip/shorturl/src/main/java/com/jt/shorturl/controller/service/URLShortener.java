package com.jt.shorturl.controller.service;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.jt.shorturl.controller.data.UrlDataStore;

import lombok.Setter;

@Service
@Setter
public class URLShortener {
	@Value(value = "${baseUrl:http://www.shrt.com/}")
	private String baseUrl;
	@Autowired
	private KeyGenerator keyGenerator;
	@Autowired
	private UrlDataStore urlDataStore;
	
	public String shortenUrl(String originalUrl) {
		String shortend = urlDataStore.fetchShortUrl(originalUrl);
		if(shortend!=null) {
			return formCompleteUrl(shortend);
		}
		Long key = keyGenerator.nextKey();
		shortend = Encoder.encode(key);
		urlDataStore.save(decodeUrl(originalUrl), shortend);
		return formCompleteUrl(shortend);
	}
	
	public String fetchOriginalUrl(String shortUrl) {
		return urlDataStore.fetchOriginal(shortUrl.replace(baseUrl, ""));
	}
	
	private String formCompleteUrl(String path) {
		StringBuilder shortUrl = new StringBuilder(baseUrl);
		shortUrl.append(path);
		return shortUrl.toString();
	}
	
	private static String decodeUrl(String url) {
		try {
			return URLDecoder.decode(url, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			//Intentionally Swallowing : UTF-8 is supported
		}
		return null;
	}
}
