package com.jt.shorturl.controller.service;

public class Encoder {
	private static final String CHAR_SET = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    private static final int    BASE     = CHAR_SET.length();

    public static String encode(Long num) {
        StringBuilder sb = new StringBuilder();
        if(num==0) sb.append(CHAR_SET.charAt(0));
        while ( num > 0 ) {
            sb.append( CHAR_SET.charAt( (int)(num % BASE) ) );
            num /= BASE;
        }
        return sb.reverse().toString();   
    }
}
