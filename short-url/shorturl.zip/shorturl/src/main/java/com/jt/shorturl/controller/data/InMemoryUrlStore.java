package com.jt.shorturl.controller.data;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Repository;

@Repository
public class InMemoryUrlStore implements UrlDataStore{

	private Map<String, String> urlMapping = new HashMap<String, String>();
	private Map<String, String> reverseMapping = new HashMap<String, String>();

	@Override
	public void save(String originalUrl, String shortUrl) {
		urlMapping.put(originalUrl, shortUrl);
		reverseMapping.put(shortUrl, originalUrl);
	}

	@Override
	public String fetchOriginal(String shortUrl) {
		return reverseMapping.get(shortUrl);
	}

	@Override
	public String fetchShortUrl(String originalUrl) {
		return urlMapping.get(originalUrl);
	}
}
