package com.jt.shorturl.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.jt.shorturl.controller.service.URLShortener;

@RestController
public class RequestReceiver {

	@Autowired
	private URLShortener shortener;

	@PostMapping("/shorten")
	public String shortenUrl(@RequestBody String originalUrl) {
		return shortener.shortenUrl(originalUrl);
	}
	
	@PostMapping("/fetch")
	public String fetchOriginalUrl(@RequestBody String shortUrl) {
		return shortener.fetchOriginalUrl(shortUrl);
	}
}
