package com.jt.shorturl.controller.service;

import java.util.concurrent.atomic.AtomicLong;

import org.springframework.stereotype.Service;

@Service
public class KeyGenerator {
	private AtomicLong keyGen = new AtomicLong(0);
	
	public Long nextKey() {
		return keyGen.getAndIncrement();
	}
}
