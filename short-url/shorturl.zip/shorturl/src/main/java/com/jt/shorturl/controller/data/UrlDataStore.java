package com.jt.shorturl.controller.data;

public interface UrlDataStore {
	void save(String originalUrl, String shortUrl);
	String fetchOriginal(String shortUrl);
	String fetchShortUrl(String originalUrl);
}
