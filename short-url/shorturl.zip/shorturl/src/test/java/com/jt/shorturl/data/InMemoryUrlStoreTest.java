package com.jt.shorturl.data;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import com.jt.shorturl.controller.data.InMemoryUrlStore;

public class InMemoryUrlStoreTest {

	@Test
	public void testSave() {
		InMemoryUrlStore urlStore = new InMemoryUrlStore();
		String originalUrl = "http://localhost";
		String shortUrl = "abcd";
		urlStore.save(originalUrl, shortUrl);
		
		assertEquals(originalUrl, urlStore.fetchOriginal(shortUrl));
		assertEquals(shortUrl, urlStore.fetchShortUrl(originalUrl));
	}
}
