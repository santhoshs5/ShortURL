package com.jt.shorturl.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.jt.shorturl.controller.data.UrlDataStore;
import com.jt.shorturl.controller.service.Encoder;
import com.jt.shorturl.controller.service.KeyGenerator;
import com.jt.shorturl.controller.service.URLShortener;

@ExtendWith(MockitoExtension.class)
public class URLShortenerTest {
	private static String baseUrl = "http://shrt.lk/";
	
	@Mock
	private KeyGenerator keyGenerator;
	@Mock
	private UrlDataStore urlDataStore;
	@InjectMocks
	private URLShortener urlShortener;

	@BeforeEach
	private void init() {
		urlShortener.setBaseUrl(baseUrl);
	}
	
	@Test
	public void testShortenUrl(){
		String originalUrl = "http://localhost";
		when(urlDataStore.fetchShortUrl(originalUrl)).thenReturn(null);
		when(keyGenerator.nextKey()).thenReturn(1l);
		String shortUrl = baseUrl + Encoder.encode(1l);
		String shortendUrl = urlShortener.shortenUrl(originalUrl);
		assertEquals(shortUrl, shortendUrl);
	}

	@Test
	public void testFetchOriginalUrl() {
		String expected = "http://localhost";
		String shortUrl = "abcd";
		when(urlDataStore.fetchOriginal(shortUrl)).thenReturn(expected);
		String originalUrl = urlShortener.fetchOriginalUrl(baseUrl + shortUrl);
		assertEquals(expected, originalUrl);
	}
}
