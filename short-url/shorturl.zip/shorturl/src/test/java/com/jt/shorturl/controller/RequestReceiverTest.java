package com.jt.shorturl.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.jt.shorturl.controller.service.URLShortener;

@ExtendWith(MockitoExtension.class)
public class RequestReceiverTest {
	
	@Mock
	private URLShortener shortener;
	@InjectMocks
	private RequestReceiver requestReceiver;
	
	@Test
	public void testShortenUrl() {
		String url = "http://localhost";
		when(shortener.shortenUrl(url)).thenReturn("abcd");
		String shortUrl = requestReceiver.shortenUrl(url);
		assertEquals("abcd", shortUrl);
	}
	
	@Test
	public void testFetchOriginalUrl() {
		String shortUrl = "abcd";
		when(shortener.fetchOriginalUrl(shortUrl)).thenReturn("http://localhost");
		String originalUrl = requestReceiver.fetchOriginalUrl(shortUrl );
		assertEquals("http://localhost", originalUrl);
	}
}
