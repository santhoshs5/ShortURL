package com.jt.shorturl.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;

import java.util.HashSet;
import java.util.Set;

import org.junit.jupiter.api.Test;

import com.jt.shorturl.controller.service.KeyGenerator;

public class KeyGeneratorTest {
	
	@Test
	public void testNextKey() {
		KeyGenerator keyGen = new KeyGenerator();
		assertEquals(0, keyGen.nextKey());
		assertEquals(1, keyGen.nextKey());
		assertEquals(2, keyGen.nextKey());
		assertEquals(3, keyGen.nextKey());
	}
	
	@Test
	public void testNextKey_parallel() {
		KeyGenerator keyGen = new KeyGenerator();
		Set<Long> existing = new HashSet<Long>();
		boolean [] failed = new boolean[1];
		for(int i=1; i<=4; i++) {
			Thread t = new Thread(
				new Runnable() {
					@Override
					public void run() {
						for(int i=1; i<=50; i++) {
							Long key = keyGen.nextKey();
							failed[0] = existing.contains(key);
							if(failed[0]) return;
							existing.add(key);
						}
					}
				}
			);
			t.start();
			try {
				t.join();
			} catch (InterruptedException e) {}
		}
		assertFalse(failed[0]);
	}
}
